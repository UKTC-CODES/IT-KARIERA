﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 22 - Задача 3
// ВИДИН_Модул-02_Упр-06_DOC-file-22_Zad-03


using System;
using System.Collections.Generic;

namespace Upr_06_DOC_22_Zad_03
{
    class Program
    {
        static void Main(string[] args) // Недовършена...
        {
            string numbers = Console.ReadLine();

            char[] numberAschar = numbers.ToCharArray();


            ulong number = ulong.Parse(Console.ReadLine());
            byte digit      = byte.Parse(Console.ReadLine());

            var result = number * digit;

            Console.WriteLine(result);

        }
    }
}
