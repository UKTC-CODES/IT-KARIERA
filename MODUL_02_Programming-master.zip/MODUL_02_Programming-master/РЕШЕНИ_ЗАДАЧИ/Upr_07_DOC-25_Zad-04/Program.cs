﻿// ВИДИН - МОДУЛ_02 - Упражнение_07 - DOC-файл 25 - Задача 1, 2, 3, 4
// ВИДИН_Модул-02_Упр-07_DOC-file-25_Зад-4


using System;
using System.Linq;

namespace Upr_07_DOC_25_Zad_04
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            // Четем броя на редове и колони
            int[] row_col = Console.ReadLine().
                            Split(" ").
                            Select(int.Parse).
                            ToArray();
            
            int[,] Ticket = new int[row_col[0], row_col[1]]; // Дефинираме матрица
            int[] ArrayRow = new int[row_col[1]]; // За четене на стойностите на един ред от матрицата



            // Въвеждаме стойности в матрицата по редове
            for (int i = 0; i < row_col[0]; i++) // цикъл за редовете
            {
                // Четем един ред
                ArrayRow = Console.ReadLine().
                            Split(" ").
                            Select(int.Parse).
                            ToArray();

                for (int j = 0; j < row_col[1]; j++) // цикъл за колоните
                {
                    // Въвеждаме реда в матрицата
                    Ticket[i, j] = ArrayRow[j];
                }
            }


            // Sum_Main_Dia (row == col) -----------------------------------------
            int Sum_Main_Dia = 0;
            for (int i = 0; i < row_col[0]; i++) // редове
            {

                for (int j = 0; j < row_col[1]; j++) // колони
                {
                    if (i == j)
                    {
                        Sum_Main_Dia += Ticket[i, j];
                    }
                }

            }
            //Console.WriteLine("Sum_Main_Dia : " + Sum_Main_Dia); // ВРЕМЕННО ЗА КОНТРОЛ

            // Sum_Sec_Dia ( row + col == row - 1 )-----------------------------------------
            int Sum_Sec_Dia = 0;
            for (int i = 0; i < row_col[0]; i++) // редове
            {

                for (int j = 0; j < row_col[1]; j++) // колони
                {
                    if (i + j == row_col[0] - 1)
                    {
                        Sum_Sec_Dia += Ticket[i, j];
                    }
                }

            }
            //Console.WriteLine("Sum_Sec_Dia : " + Sum_Sec_Dia); // ВРЕМЕННО ЗА КОНТРОЛ

            // Sum_Over_Main_Dia ( row < col )-----------------------------------------
            int Sum_Over_Main_Dia = 0;
            for (int i = 0; i < row_col[0]; i++) // редове
            {

                for (int j = 0; j < row_col[1]; j++) // колони
                {
                    if (i < j)
                    {
                        Sum_Over_Main_Dia += Ticket[i, j];
                    }
                }

            }
            //Console.WriteLine("Sum_Over_Main_Dia : " + Sum_Over_Main_Dia); // ВРЕМЕННО ЗА КОНТРОЛ

            // Sum_Below_Main_Dia ( row > col )-----------------------------------------
            int Sum_Below_Main_Dia = 0;
            for (int i = 0; i < row_col[0]; i++) // редове
            {

                for (int j = 0; j < row_col[1]; j++) // колони
                {
                    if (i > j)
                    {
                        Sum_Below_Main_Dia += Ticket[i, j];
                    }
                }

            }
            //Console.WriteLine("Sum_Below_Main_Dia : " + Sum_Below_Main_Dia); // ВРЕМЕННО ЗА КОНТРОЛ

            // Calculate profit
            int Sum_Main_Dia_Even = 0;
            for (int i = 0; i < row_col[0]; i++) // редове
            {

                for (int j = 0; j < row_col[1]; j++) // колони
                {
                    if (i == j)
                    {
                        if (Ticket[i, j]%2 == 0)
                        {
                            Sum_Main_Dia_Even += Ticket[i, j];
                        }
                        
                    }
                }

            }
            //Console.WriteLine("Sum_Main_Dia_Even : " + Sum_Main_Dia_Even); // ВРЕМЕННО ЗА КОНТРОЛ

            int Sum_Fist_Last_Row_Even = 0;
            for (int j = 0; j < row_col[1]; j++) // колони
            {
                if (Ticket[0, j]%2 == 0 )// First row
                {
                    Sum_Fist_Last_Row_Even += Ticket[0, j];
                }

                if (Ticket[row_col[0]-1, j] % 2 == 0) // Last row
                {
                    Sum_Fist_Last_Row_Even += Ticket[row_col[0]-1, j];
                }
            }
            //Console.WriteLine("Sum_Fist_Last_Row_Even : " + Sum_Fist_Last_Row_Even); // ВРЕМЕННО ЗА КОНТРОЛ

            int Sum_Fist_Last_Column_Odd = 0;
            for (int i = 0; i < row_col[1]; i++) // редове
            {
                if (Ticket[i, 0] % 2 != 0)// First column
                {
                    Sum_Fist_Last_Column_Odd += Ticket[i, 0];
                }

                if (Ticket[i, row_col[1]-1] % 2 != 0) // Last column
                {
                    Sum_Fist_Last_Column_Odd += Ticket[i, row_col[1]-1];
                }
            }
            //Console.WriteLine("Sum_Fist_Last_Column_Odd : " + Sum_Fist_Last_Column_Odd); // ВРЕМЕННО ЗА КОНТРОЛ


            float Profit = (  Sum_Below_Main_Dia
                            + Sum_Main_Dia_Even
                            + Sum_Fist_Last_Row_Even
                            + Sum_Fist_Last_Column_Odd) / 4;


            // Check the ticket
            if (Sum_Main_Dia == Sum_Sec_Dia && Sum_Over_Main_Dia%2 ==0 && Sum_Below_Main_Dia%2 !=0)
            {
                Console.WriteLine("YES");
                Console.WriteLine("The amount of money won is: {0:f2}",Profit);
            }
            else
            {
                Console.WriteLine("NO");
            }




/*

            // Print matrix - Just to check the matrix
            //-----------------------------------------

            for (int i = 0; i < row_col[0]; i++)
            {

                for (int j = 0; j < row_col[1]; j++)
                {
                    Console.Write( Ticket[i, j] + " ");
                }

                Console.WriteLine();
            }

    */

        }
    }
}
