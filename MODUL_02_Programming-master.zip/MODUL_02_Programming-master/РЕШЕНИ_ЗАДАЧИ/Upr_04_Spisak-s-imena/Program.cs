﻿

using System;
using System.Collections.Generic;
using System.Linq;

namespace Upr_04_Spisak_s_imena
{
    class Program
    {
        static void Main(string[] args)
        {
            /*

            // Упражнение_04 (папка 4), DOC-файл 13 //////////////////////////////////////////////////////////////////////
            //-------------------------------------------

         // 2. Списък от имена ..........................................................
                       List<string> myList1 =   Console.ReadLine().
                                               Split(" ").
                                               //Sеlect(*.Parse).
                                               ToList();

                       Console.WriteLine(String.Join("; ", myList1));




         // 3. Списък от имена II .......................................................
                       List<string> myList2 = Console.ReadLine().
                                               Split(", ").
                                               //Select(*.Parse).
                                               ToList();


                       foreach(string myItem in myList2)
                       {
                           string[] separatedItem = myItem.Split(" ");
                           Console.WriteLine(separatedItem[1] + " " + separatedItem[0]);

                       }





             // Упражнение_04 (папка 4), DOC-файл 14 //////////////////////////////////////////////////////////////////////
             //--------------------------------------------


         // 2. Списък от четни числа...........................

                       List<int> myList3 = Console.ReadLine().
                                               Split(" ").
                                               Select(int.Parse).
                                               ToList();

                       foreach(int myNum in myList3)
                       {
                           if(myNum % 2 ==0)
                           {
                               Console.Write(myNum + " ");
                           }
                       }



                       // 3. Списък от крайности ...........................

                       List<int> myList4 = Console.ReadLine().
                                              Split(" ").
                                              Select(int.Parse).
                                              ToList();

                       int Min = myList4.Min();
                       int Max = myList4.Max();

                       foreach (int myNum in myList4)
                       {
                           if (myNum == Min || myNum == Max)
                           {
                               Console.Write(myNum + " ");
                           }
                       }

            
        // 4.	Максимална поредица еднакви числа ...........................
            List<int> myList5 = Console.ReadLine().
                                        Split(" ").
                                        Select(int.Parse).
                                        ToList();

            int currentValue = 0;
            int currentStart = 0;
            int currentLength = 0;

            int bestValue = 0;
            int bestStart = 0;
            int bestLength = 0;


            for (int i = 0; i < myList5.Count-1; i++) // Обхождаме списъка и увеличаваме съответния брояч
            {
                currentValue = myList5[i];
                currentStart = i;
                currentLength = 0;

                while (currentValue == myList5[i] && i < myList5.Count-1)
                {
                    currentLength++;
                    i++;


                    if (bestLength < currentLength)
                    { 
                        bestLength = currentLength;
                        bestStart = currentStart;
                        bestValue = currentValue;
                    }
                }
            }


            for (int j = 1; j <= bestLength; j++)
            {
                Console.Write(bestValue + " ");
            }

  


   // 5.	Сума на обърнати числа ...........................

            List<string> myList6 = Console.ReadLine().
                                        Split(" ").
                                        //Select(int.Parse).
                                        ToList();
            int sum = 0;


            for (int i = 0; i < myList6.Count; i++)
            {
                char[] currString = myList6[i].ToCharArray();// Всеки от елементите на списъка се превръща в
                                                             // масив орт символи

                Array.Reverse(currString); // Реверсира се масива

                string revString = new string(currString); // Масива се конвертира в стринг

                int curValue = int.Parse(revString); // Стринга се парсва към целочислен


                sum += curValue; // сумират се реверсираните стойности

            }


            Console.WriteLine(sum);

   



            // Упражнение_04 (папка 4), DOC-файл 16 //////////////////////////////////////////////////////////////////////
            //--------------------------------------------

            // 3.Числа квадрати ................................

            List<int> myList7 = Console.ReadLine().
                                        Split(" ").
                                        Select(int.Parse).
                                        ToList();

            List<int> squares = new List<int>();
            int i = 0;

            foreach (int item in myList7)
            {
                if (Math.Sqrt(item) == (int)Math.Sqrt(item))
                {
                    squares.Add(item);
                }

            }



            // squares = squares.Sort((a, b) => b.CompareTo(a));
            squares.Sort();
            squares.Reverse();


            foreach (var myItem in squares)
            {
                Console.Write(myItem + " ");
            }



            // 4. Брой числа ................................
            List<int> myList8 = Console.ReadLine().
                                        Split(" ").
                                        Select(int.Parse).
                                        ToList();

            int[] numbers = new int[myList8.Count];
           
            myList8.Sort();

            for (int i = 0; i <= myList8.Count-1; i++)
            {
                numbers[i] = myList8[i];
            }

            // Console.WriteLine(String.Join(" ", numbers));

            int j = 0;
            int counter = 0;
            int current = numbers[j];

            for (j = 0;j < numbers.Length-1; j++)
            {
                counter = 0;

                while (current == numbers[j] )
                {
                    counter++;
                    j++;

                    if (j == numbers.Length) { break; }
                }

                Console.WriteLine(current + " -> " + counter);

                if (j < numbers.Length - 1) { current = numbers[j]; }

                    j--;
            }
            
    
    */

            //  1 1 1 1 2 2 2 4 4 4 4 4 3 3 3 7 7 7 8 8 8 8 8 8

        }
    }
}
