﻿using System;
using System.Linq;

namespace Upr_04_Obrabotka_na_masiv
{
    class Program
    {

        /*
         
        Вие ще получите масив от низове и трябва да изпълните командите под тях.Вие можете да получите три команди:

    •	Reverse – обръща реда в масива
    •	Distinct – изтрива всички неуникални(повтарящи се) елементи на масива
    •	Replace {index} {string} – замества елемента на дадената позиция index  с низ string, който ви е даден

        */

        
        static void Main(string[] args)
        {

            string[] Input = Console.ReadLine(). //Дефинираме масив и въвеждаме стойностите от един ред
                            Split(" ").
                            //Select(int.Parse).
                            ToArray();


            int commands = int.Parse(Console.ReadLine());// брой команди



            for (int i = 1; i <= commands; i++)// цикъл за броя команди
            {

                // Чете командата от клавиатурата и слага всяка част в отделен стринг
                string[] command = Console.ReadLine(). // дефинира масив за въвеждане на команда
                                   Split(" ").         // командата е като масив от стрингове разделени с интервал
                                   ToArray();          // елемент[0] е командата
                                                       // другите [1][2]...[n], ако има са параметри


                Console.WriteLine(String.Join(" ", command));// не е нужно - зa текуща визуализация на командата


                // Анализ на командата и изпълнението ///////////////////////////////////////////////

                // команда Reverse - обръща масива в обратен ред
                if (command[0].Equals("Reverse"))
                {
                    Array.Reverse(Input);
                }


                // команда Distinct - премахва дублиращи се елемнти
                if (command[0].Equals("Distinct"))
                {
                    Input = Input.Distinct().ToArray();
                }


                // команда Replace - заменя елемента от даден индекс с друг елемент
                if (command[0].Equals("Replace")) // елемент[0] - команда
                {
                    int index = int.Parse(command[1]);  // елемент[1] - параметър 1 (индекса)
                    string replace = command[2];        // елемент[2] - параметър 2 (думата с която да заменим)

                    Input[index] = replace;

                }


                // PRINT RESULT ///////////////////////////////////////
                Console.WriteLine(String.Join(" ", Input));// не е нужно - за текуща информация на масива

            }

            Console.WriteLine(String.Join(" ", Input));// Това е крайния резултат


            // Всичко коментирано с "не е нужно" да се изтрие в окончателния вариант

        }
    }
}
