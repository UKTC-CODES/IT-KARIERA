﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// ПРЕОБРАЗУВАНЕ 10-ИЧНА В N-ИЧНА :  



namespace Upr_06_Zadacha_01
{
    class Program
    {
        static void Main(string[] args)
        {

            int N, D; // N- основа на бройната система; D-число за преобразуване
            var remain = new List<int>(); // Създава списък за остатъците


            // Четене от един ред
            int[] read = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            N = read[0];
            D = read[1];



            if (N >= 2 && N <= 10)

            {
                // Изчисляване на остатъците
                while (D > 0)
                {

                    remain.Add(D % N);
                    D = D / N;
                    // Console.WriteLine("Числото след деление: {0}",D);

                }

                Console.WriteLine();

                {

                    remain.Reverse(); // Инвертиране на списъка

                    Console.WriteLine(String.Join("", remain)); // Разпечатване на списъка

                }

            }
            else
                Console.WriteLine(0);


            Console.WriteLine();



        }
    }
}
