﻿using System;
using System.Linq;

namespace Upr_04_Zavurtane_i_sumirane
{
    class Program
    {
        static void Main(string[] args)
        {
            // INPUT 
            int[] numbers = Console.ReadLine(). //Дефинираме масив и въвеждаме стойности от един ред
                             Split(" ").
                             Select(int.Parse).
                             ToArray();


            int k = int.Parse(Console.ReadLine()); // брой завъртания
            // Console.WriteLine("-----------------------"); // не е задължително


            int n = numbers.Length; // брой числа в масива
            int[] sum = new int[n]; // масив за сумите
            


            // LOGIC
            for (int r = 1; r <= k; r++)
            {
                for (int i = 0; i <= n-1; i++)
                {
                    // Console.WriteLine((i + r) % n);// Временно зада видя какво става вътре в цикъла
                    
                    sum[(i + r) % n] = sum[(i + r) % n] + numbers[i];

                    //sum[i] = sum[i] + numbers[(i + r) % n]; // Не работи, само за проба
                }

            }


            // PRINT RESULT
            Console.WriteLine(String.Join(" ", sum));

        }
    }
}
