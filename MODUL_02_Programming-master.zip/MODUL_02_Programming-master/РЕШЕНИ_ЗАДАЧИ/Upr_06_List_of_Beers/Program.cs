﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upr_06_List_of_Beers
{
    class Program
    {
        static void Main(string[] args)
        {

            string listOfBeers = "Amstel, Zagorka, Tuborg, Becks.";
            string[] beers = listOfBeers.Split(' ', ',', '.');

            Console.WriteLine("Available beers are:");
            Console.WriteLine();

            foreach (string beer in beers)
                Console.WriteLine(beer);

            Console.WriteLine();
            Console.WriteLine();

            for (int i= 0; i<beers.Length; i++)
            {

                Console.WriteLine(beers[i]);

            }



        }
    }
}
