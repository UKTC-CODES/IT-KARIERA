﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 23 - Задача 1, 2, 3, 4
// ВИДИН_Модул-02_Упр-06_DOC-file-23_Зад-1

using System;
using System.Collections.Generic;

namespace Upr_06_DOC_23
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            string inputStr = Console.ReadLine(); // Входен стринг
            string template = Console.ReadLine(); // шаблон

            List<int> occureIndex = new List<int>(); // Списък с индексите на които има срещания

            while (template.Length > 0 && inputStr.Length > template.Length)
            {

                // Проверява колко срещания има на темплейта в стринга
                for (int i = 0; i <= inputStr.Length - 0 - template.Length; i++)
                {
                    string tempStr = inputStr.Substring(i, template.Length);

                    if (tempStr == template)
                    {
                        occureIndex.Add(i);
                    }
                }


                // Console.WriteLine(occureIndex.Count);             // ВРЕМЕННО - за контол
                // Console.WriteLine(String.Join(" ", occureIndex)); // ВРЕМЕННО - за контол

                if (occureIndex.Count > 1) // Ако шаблона се среща повече от веднъж
                {
                    // Премахване на първото и последното срещания
                    inputStr = inputStr.Remove(occureIndex[0], template.Length);// първото срещане
                    inputStr = inputStr.Remove(occureIndex[occureIndex.Count - 1]-template.Length, template.Length);// последното срещане

                    // Редуцира шаблона - премахва един символ на позиция дължината му делена на 2
                    template = template.Remove(template.Length / 2, 1);

                    // изчисва списъка със срещания, за да е готов за ново търсене с редуцирания шаблон
                    occureIndex.Clear();

                    Console.WriteLine("Shaked it.");
                }
                else
                {
                    Console.WriteLine("No Shake.");
                    //Console.WriteLine(inputStr);
                    break;
                }


            } // end while

            Console.WriteLine(inputStr);
        }
    }
}



// TRY IT : ABACCCCABACCCCABA
//          ABA
// ANSWER : Shaked it.
//          No Shake.
//          CCCCABACCCC



// TRY IT : inputStr : abbacccabbacccccabbacccccabba
//        : template : abb
// ANSWER : 
//                      Shaked it.
//                      Shaked it.
//                      cccbacccccbaccccc

// TRY IT : inputStr : abbacccabbacccccabbacccccabba
//        : template : abba
// ANSWER : 
//                      Shaked it.
//                      No Shake.
//                      cccabbacccccabbaccccc
