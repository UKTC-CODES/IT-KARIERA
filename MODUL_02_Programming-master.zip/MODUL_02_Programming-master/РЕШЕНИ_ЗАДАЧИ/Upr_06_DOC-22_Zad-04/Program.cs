﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 22 - Задача 4 - Обработка на числа с представки
// ВИДИН_Модул-02_Упр-06_DOC-file-22_Зад-4


using System;
using System.Collections.Generic;
using System.Linq;

namespace Upr_06_DOC_22_Zad_04
{
    static class Program
    {
        static void Main(string[] args)
        {

            List<string> inputValues =  Console.ReadLine().
                                        Split(" ").
                                        //Select().
                                        ToList();
            double sumOfSum = 0;

            foreach (var input in inputValues)
            {
                string remainStr = input.Substring(1, input.Length - 2);
                // Console.WriteLine("remain string : " + remainStr);// ВРЕМЕННО

                double remain = int.Parse(remainStr);

                // Console.WriteLine("First letter ASCII : " + (int)input[0]);                  // ВРЕМЕННО
                // Console.WriteLine("Last letter ASCII : " + (int)input[input.Length - 1]);    //ВРЕМЕННО

                //First Letter--------------------------------------------------------------------
                    if (Char.IsUpper(input[0]))
                    {
                        remain = remain / ((int)(input[0] - 64));
                    }

                    if (Char.IsLower(input[0]))
                    {
                        remain = remain * ((int)(input[0] - 96));
                    }

                    // Console.WriteLine("remain after First letter : " + remain); // ВРЕМЕННО за контрол

                    //Last Letter----------------------------------------------------------------
                    if (Char.IsUpper(input[input.Length - 1]))
                    {
                        remain = remain - ((int)(input[input.Length - 1] - 64));
                    }

                    if (Char.IsLower(input[input.Length - 1])) // последния символ
                    {
                        remain = remain + ((int)(input[input.Length - 1] - 96));
                    }

                    // Console.WriteLine("remain after Last letter : " + remain); // ВРЕМЕННО за контрол

                sumOfSum += remain;

            } // end foreach

            Console.WriteLine(Math.Round(sumOfSum, 2, MidpointRounding.AwayFromZero));

            // Console.WriteLine("FINAL SumOfSum (without rounding): " + sumOfSum); // ВРЕМЕННО - за контрол
            


        }
    }
}


// ВХОД ЗА ТЕСТ : A12b s17G
// ВХОД ЗА ТЕСТ : P34562Z q2576f H456z
// ВХОД ЗА ТЕСТ : a1A