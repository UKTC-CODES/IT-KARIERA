﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 21 - Задача 6

using System;

namespace Upr_06_DOC_21_Zadacha_06
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();          // Входящ стринг
           
            char[] inToCharArr = input.ToCharArray();   // Конвертиран към масив от символи
           
            Array.Reverse(inToCharArr);                 // Реверсиран масив от символи
         
            string revinput = new string (inToCharArr); // Конвертиран обатно към стринг

             // Console.WriteLine(reversedInput);       //ВРЕМЕННО за контрол
            
           
            bool palindrome = (input == revinput); // Проверка за равенство (еднаквост)

            Console.WriteLine(palindrome);

        }
    }
}


// TRY IT : ahfldoetteodlfha --> TRUE
// TRY IT : ;lkkjakjajfdglijrg'jfdg'jddj'gdfj'grjilgdfjajkajkkl; --> TRUE