﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 21 - Задача 5

using System;
using System.Collections.Generic;
using System.Linq;
//using System.*;

namespace Upr_06_DOC_21_Zad_5
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] splitter = new char[] { ',', ';', ':', '.', '!', '(', ')', '"', '\'', '\\', '/', '[', ']', ' ' };

            // Въвеждане на поредица от числа в списък
            List<string> values = Console.ReadLine().
                                        Split(splitter, StringSplitOptions.RemoveEmptyEntries).
                                        //Select(int.Parse).
                                        ToList();

            
            int result = Sum_sum(values[0], values[1]); // Извикване на метода Sum_sum

            Console.WriteLine(result);

        }// end of MAIN


        // Метод за сумиране символ по символ ---------------------------------------------
        static int Sum_sum (string param1, string param2)
        {

            int summa = 0;
           
            // Ако ПЪРВИЯ параметър е по-голям
            if(param1.Length >= param2.Length)
            {
                for (int i = 0; i < param2.Length; i++)
                {
                        summa += (param1[i] * param2[i]);

                }

                for (int j = param2.Length-1; j < param1.Length-1; j ++)
                {
                    summa += param1[j];
                }

            }

            // Ако ВТОРИЯ параметър е по-голям
            if (param2.Length >= param1.Length)
            {
                for (int i = 0; i < param1.Length; i++)
                {
                    summa += (param1[i] * param2[i]);

                }

                for (int j = param1.Length - 1; j < param2.Length - 1; j++)
                {
                    summa += param2[j];
                }

            }

            return summa;
        }


    }
}
