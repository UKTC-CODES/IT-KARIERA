﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 21

using System;
using System.Collections.Generic;
using System.Linq;

namespace Upr_06_DOC_21
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
                        // Задача. 1. Преобразуване от 10-ична в N-ична ПБС
                        // ----------------------------------------------------------------------------------------------------


                        char[] splitter = new char[] { ',', ';', ':', '.', '!', '(', ')', '"', '\'', '\\', '/', '[', ']', ' ' };

                        // Въвеждане на поредица от числа в списък
                        List<int> command = Console.ReadLine().
                                                    Split(splitter, StringSplitOptions.RemoveEmptyEntries).
                                                    Select(int.Parse).
                                                    ToList();
                                                    // ToArray();
                                                    // ToString();

                        List<int> converted = new List<int>();
                        int baseCS = command[0];    // Основата на N-ичната бройна система
                        int number = command[1];    // Числото в 10-чна бройна система
                        int whole = number / baseCS;
                        int remain = 0;

                        while (whole > 0)
                        {
                            whole = number / baseCS;
                            remain = number % baseCS;
                            number = whole;
                            converted.Add(remain);
                        }

                        converted.Reverse();
                        Console.WriteLine(String.Join("", converted));



                        // Задача. 2. Преобразуване от N-ична в 10-ична ПБС
                        // -----------------------------------------------------------------------------------------------------


                        // Въвеждане на поредица от числа в списък
                        List<string> command = Console.ReadLine().
                                                    Split(" ", StringSplitOptions.RemoveEmptyEntries).
                                                    //Select(int.Parse).
                                                    ToList();
                        

                        int baseCS = int.Parse(command[0]);         // Основата на N-ичната бройна система
                        char[] number = command[1].ToCharArray();   // Числото в N-чна бройна система в масив
                                                                    // за да го обработвам цифра по цифра

                        int power;
                        int value;
                        int converted = 0;
                        int digits = number.Count()-1;

                        for (int i = digits; i >=0; i--)
                        {
                            power = number.Count() - 1 - i;

                            value = Convert.ToInt32(number[i].ToString());

                            converted += value * (int)(Math.Pow(baseCS, power));

                        }

                        Console.WriteLine(String.Join("", converted));

         

            // Задача. 3. Обръщане на низ
            // -----------------------------------------------------------------------------------------------------

            string input = Console.ReadLine();
            string reversed = null;

            for (int i = input.Length - 1; i >= 0 ; i--)
            {
                reversed += input[i];
            }

            Console.WriteLine(reversed);


            // Задача. 4.	Unicode Символи
            // -----------------------------------------------------------------------------------------------------

            string input = Console.ReadLine();
            //string unicode;

            for (int i = 0; i < input.Length; i++)
            {
                
                Console.Write("\\u{0:x4}", (int)input[i]);
                //Console.WriteLine((int)input[i]);

            }

 */

            // Задача.5.	Умножаване на символни кодове
            // -----------------------------------------------------------------------------------------------------

            // ... to be continued ...


        }
    }
}
