﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upr_06_Zabraneni_Dumi
{
    class Program
    {
        static void Main(string[] args)
        {

            string ZabrNiz;
            ZabrNiz = Console.ReadLine();


            string Text;
            Text = Console.ReadLine();

            

            string ReplStr = new string('*', ZabrNiz.Length);

            string ReplText = Text.Replace(ZabrNiz, ReplStr);

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("RESULT : ");
            Console.WriteLine("=========");

            Console.WriteLine();
            Console.WriteLine("ORIGINAL : ");
            Console.WriteLine(Text);


            Console.WriteLine();
            Console.WriteLine("REPLACED : ");
            Console.WriteLine(ReplText);



        }
    }
}
