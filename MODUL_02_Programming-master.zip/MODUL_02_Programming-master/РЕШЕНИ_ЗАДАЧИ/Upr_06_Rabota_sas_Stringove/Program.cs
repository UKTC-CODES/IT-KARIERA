﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Upr_06_Rabota_sas_Stringove
{
    class Program
    {
        static void Main(string[] args)
        {


            // Trim без параметри
            Console.WriteLine("Trim без параметри : ");
            string s = "    example of white space    .";
            string clean = s.Trim();
            Console.WriteLine(clean); // example of white space
           
            Console.WriteLine();
            Console.WriteLine();


            // Trim с параметри
            Console.WriteLine("Trim С параметри : ");
            string s1 = " \t\nHello!!! \n";
            string clean1 = s1.Trim(' ', ',', '!', '\n', '\t');
            Console.WriteLine(clean1); // Hello

            Console.WriteLine();
            Console.WriteLine();



            // TrimStart и  TrimEnd
            Console.WriteLine("TrimStart и  TrimEnd : ");
            string s2 = "   C#   ";
            string clean2 = s2.TrimStart();
            Console.WriteLine(clean2);// clean = "C#   "

            string clean3 = s2.TrimEnd();
            Console.WriteLine(clean3);// clean = "    C#"

            Console.WriteLine();
            Console.WriteLine();



            // Таймер

            var timer = new Stopwatch();
            timer.Start();

            string result = "";
            for (int i = 0; i < 30000; i++)
                result += Convert.ToString(i, 2);

            Console.WriteLine(result.Length);
            Console.WriteLine(timer.Elapsed);

            var MyStringBuild = new StringBuilder();

           // MyStringBuild.Append();
           // MyStringBuild.Capacity();
           // MyStringBuild.Remove();
           // MyStringBuild.Replace();
           // MyStringBuild.Insert();






        }
    }
}
