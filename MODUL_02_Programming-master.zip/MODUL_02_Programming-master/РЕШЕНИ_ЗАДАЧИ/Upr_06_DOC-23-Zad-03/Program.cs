﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 23 - Задача 1, 2, 3, 4
// ВИДИН_Модул-02_Упр-06_DOC-file-23_Зад-3


using System;
using System.Collections.Generic;
using System.Linq;

namespace Upr_06_DOC_23_Zad_03
{
    internal static class Program
    {
        private static void Main(string[] args)
        {

            string inputStr = Console.ReadLine();        // Входен стринг
            List<int> occureIndex = new List<int>();     // Списък с индексите на които има срещания на цифра
            char[] inputToChar = inputStr.ToCharArray(); // Входни стринг конвертиран към масив от символи



            while (true)
            {

                string[] evidences = Console.ReadLine().
                                        Split(" ", StringSplitOptions.RemoveEmptyEntries).
                                        ToArray();

                char searchItem = Convert.ToChar(evidences[0]);
                int countSearched = int.Parse(evidences[1]);

                // Цикъл за обхождане на входния стринг
                for (int i = 0; i < inputToChar.Length; i++)
                {

                    // Проверка за срещане на символа
                    while (inputToChar[i].Equals(searchItem) && i <= inputToChar.Length - 1) // 
                    {
                        occureIndex.Add(i); // Ако се срещне се записва индекса му
                        i++;
                        //if (i >= inputToChar.Length - 1) { break; }
                    }
                

                    if (occureIndex.Count >= countSearched)
                    {
                        Console.WriteLine($"Hideout found at index { occureIndex[0]} " +
                                          $"and it is with size { occureIndex.Count} !");
                        break;
                    }
                    else
                    {
                        occureIndex.Clear(); // Нулира списъка със срещанията
                    }

                } // end for
                
            } // end while

          
        } // end Main
    } // end Program
}

// ПРОВЕРКА : asd@@asdasd@@@@@@@asdasd asdsad
// ТЪРСИМ   : @ 5
// ОТГОВОР  : Hideout found at index 11 and it is with size 7!

// ПРОВЕРКА : asd@@asd***asdasdsad123%4521Asdsad************ASssda
// ТЪРСИМ   : * 10
//ОТГОВОР   : Hideout found at index 34 and it is with size 12!