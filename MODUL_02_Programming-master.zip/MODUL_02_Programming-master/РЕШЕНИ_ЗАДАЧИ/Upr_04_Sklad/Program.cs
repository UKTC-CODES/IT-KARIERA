﻿using System;
using System.Linq;

namespace Upr_04_Sklad
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] Products = Console.ReadLine(). //Дефинираме масив за продукти и въвеждаместойностите от един ред
                           Split(" ").
                           //Select(int.Parse).
                           ToArray();

            long[] Quantity = Console.ReadLine(). //Дефинираме масив за количества и въвеждаме стойностите от един ред
                           Split(" ").
                           Select(long.Parse).
                           ToArray();

            float[] Prices = Console.ReadLine(). //Дефинираме масив за цени и въвеждаме стойностите от един ред
                           Split(" ").
                           Select(float.Parse).
                           ToArray();

            string product;


            while(true)
            {

                product = Console.ReadLine();

                if (product.Equals("done"))
                    break;

                int index = Array.IndexOf(Products, product);
                Console.WriteLine($"{Products[index]} costs: {Prices[index]}; Available quantity: {Quantity[index]}");
               
            }
        }
    }
}
