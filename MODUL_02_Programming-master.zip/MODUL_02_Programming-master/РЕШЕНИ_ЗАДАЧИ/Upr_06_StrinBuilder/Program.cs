﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// Въвеждане стринг и команда за манипулацията му


namespace Upr_06_StrinBuilder
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input string : ");
            string InString = Console.ReadLine(); //Read string
            Console.WriteLine();

            Console.Write("Input command and parameters : ");
            string InCommand = Console.ReadLine();// Read comands
            Console.WriteLine();


            // Преобразуване на Входния стринг в Стринг-Билдер и добавянето му
            var InStrBuilder = new StringBuilder();
            InStrBuilder.Append(InString);
            //Console.WriteLine(InStrBuilder);



            // Преобразуване на Kомандата в масив от стрингове
            string[] InComm = InCommand.Split(' ');

            // Разпечатване на масива
            // foreach (string InStr in InComm )
            // Console.WriteLine(InStr);
            
            //Console.Write(string.Join(" ", InComm[])); // Разпечатва масива InComm[]





            Console.WriteLine();



        }
    }
}
