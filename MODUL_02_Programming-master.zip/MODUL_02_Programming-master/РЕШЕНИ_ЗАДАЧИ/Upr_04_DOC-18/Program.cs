﻿//  ВИДИН - МОДУЛ_02; Упражнение 04 ; DOC-ФАЙЛ 18;

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Upr_04_DOC_18
{
    class Program
    {
        static void Main(string[] args)
        {

            /*

                    // -------------------------------------------------------------------------------------------
                    // ЗАДАЧА 1.	Сума на съседни еднакви числа ------------------------------------------------

                    List<int> myList1 = Console.ReadLine().
                                                   Split(" ").
                                                   Select(int.Parse).
                                                   ToList();

                    int i = 0;

                    while (myList1.Count > 2 && i < myList1.Count-1)
                    {
                        if (myList1[i] == myList1[i+1])
                        {
                            myList1[i] = myList1[i] + myList1[i + 1];
                            myList1.RemoveAt(i+1);
                            i=-1;

                            Console.WriteLine(String.Join(" ", myList1));// За текущ контрол на сисъка (не се изисква в задачата)
                        }

                        i++;

                    }

                    Console.WriteLine();
                    Console.WriteLine(String.Join(" ", myList1));


                    // ЗА ПРОВЕРКА НА КОДА :
                    // 8 2 2 4 8 16 ---> 16 8 16
                    // 3 3 6 1      ---> 12 1
                    // 5 4 2 1 1 4  ---> 5 8 4
                    // 7 5 5 10 8 8 16 16 -> 7 10 10 8 8 16 16 -> 7 20 8 8 16 16 -> 7 20 16 16 16 ---> 7 20 32 16

        

            // ---------------------------------------------------------------------------------------
            // ЗАДАЧА 2. Отделяне по регистър на дума ------------------------------------------------

            // Полезен ресурс : https://stackoverflow.com/questions/27402126/check-if-string-have-uppercase-lowercase-and-number/27402159

            // Използвайте следните разделители между думите: , ; : . ! ( ) " ' \ / [ ] интервал
            // Lower-case: 
            // Mixed-case: 
            // Upper-case: 

            char[] splitter = new char[] { ',', ';', ':', '.', '!', '(', ')', '"', '\'', '\\', '/', '[', ']', ' ' };

            List<string> myList2 = Console.ReadLine().
                                           Split(splitter, StringSplitOptions.RemoveEmptyEntries).
                                           // Сплитва по който и да е от символите в масива splitter
                                           //Select(int.Parse).
                                           ToList();

            List<string> upperList = new List<string>();
            List<string> lowerList = new List<string>();
            List<string> mixedList = new List<string>();

            for (int i = 0; i < myList2.Count-1; i++)
            {
                if(myList2[i].Equals(' '))
                {
                    myList2.RemoveAt(i);
                }

            }

       
            foreach (var myString in myList2)
            {

                
                myString.Trim(' ');
                

                // MIXED - ANY
                if ( myString.Any(char.IsUpper) && myString.Any(char.IsLower) )
                {
                    mixedList.Add(myString);
                }


                // UPPER - ALL
                if ( myString.All(char.IsUpper) )
                {
                    upperList.Add(myString);
                }


                //LOWER - ALL
                if ( myString.All(char.IsLower))
                {
                    lowerList.Add(myString);
                }


            }


            Console.WriteLine("Lower-case: " + String.Join(", ", lowerList));
            Console.WriteLine("Mixed-case: " + String.Join(", ", mixedList));
            Console.WriteLine("Upper-case: " + String.Join(", ", upperList));

            // ПРОВЕРКА : 
            // Learn programming at SoftUni: Java, PHP, JS, HTML 5, CSS, Web, C#, SQL, databases, AJAX, etc.

    
            // ---------------------------------------------------------------------------------------
            // ЗАДАЧА 3. Променлив списък ------------------------------------------------

            char[] splitter = new char[] { ',', ';', ':', '.', '!', '(', ')', '"', '\'', '\\', '/', '[', ']', ' ' };

            List<int> myList3 = Console.ReadLine().
                                           Split(splitter, StringSplitOptions.RemoveEmptyEntries).
                                                // Сплитва по който и да е от символите в масива splitter
                                                // и премахва празни елементи ако са "влезли"
                                           Select(int.Parse).
                                           ToList();
                                           // ToArray();
                                           // ToString();

            while (true)
            {

                string[] commands = Console.ReadLine().
                                           Split(' ').
                                           //Select(int.Parse).
                                           ToArray();

                if (commands[0].Equals("Delete"))
                {
                    int temp = int.Parse(commands[1]);
                 
                        myList3.RemoveAll(items => items == temp);
                        // Lambda израз ( items => items == temp )
                        // Изтрива всички елементи които са равни
                        // на подадената стойност след Delete
                        // => се чете "сочи към"
                }


                if (commands[0].Equals("Insert"))
                {
                    myList3.Insert(int.Parse(commands[2]), int.Parse(commands[1]));
                                          // на кой индекс           кой елемент
                }


                if (commands[0].Equals("Even"))
                {
                    Console.WriteLine(String.Join(" ", myList3.FindAll(item => (item % 2) == 0)));
                    // Lambda израз ( items => (item % 2) == 0 ) - ЧЕТНИ
                    // Извлича всички елементи които са равни
                    // на зададеното условие - ЧЕТНИ ЕЛЕМЕНТИ;
                    // => се чете "сочи към"
                    break;
                }


                if (commands[0].Equals("Odd"))
                {
                    Console.WriteLine(String.Join(" ", myList3.FindAll(item => (item % 2) != 0)));
                    // Lambda израз ( items => (item % 2) != 0 ) - НЕЧЕТНИ
                    // Извлича всички елементи които са равни
                    // на зададеното условие - НЕЧЕТНИ ЕЛЕМЕНТИ;
                    // => се чете "сочи към"
                    break;
                }

                // ПРОВЕРКА :
                // 20 12 4 319 21 31234 2 41 23 4
                // Insert 50 2
                // Insert 50 5
                // Delete 4
                // Even
                //
                // ОТГОВОР : 20 12 50 50 31234 2


            // ---------------------------------------------------------------------------------------
            // ЗАДАЧА 4. Търсене на число ------------------------------------------------

            char[] splitter = new char[] { ',', ';', ':', '.', '!', '(', ')', '"', '\'', '\\', '/', '[', ']', ' ' };

            // Въвеждане на поредица от числа в списък
            List<int> myList4 = Console.ReadLine().
                                        Split(splitter, StringSplitOptions.RemoveEmptyEntries).
                                                // Сплитва по който и да е от символите в масива splitter
                                                // StringSplitOptions.RemoveEmptyEntries - премахва празни елемнти
                                        Select(int.Parse).
                                        ToList();
                                        // ToArray();
                                        // ToString();
                                           

            // Въвеждаме 3те числа от конзолата и ги записваме в целочислен масив
            int[] input = Console.ReadLine().
                                           Split(splitter, StringSplitOptions.RemoveEmptyEntries).
                                           Select(int.Parse).
                                           // ToList();
                                           ToArray();
                                           // ToString();


            int itemsToTake     = input[0]; // P
            int itemsToDelete   = input[1]; // Q
            int numberToSearch  = input[2]; // R

            myList4 = myList4.Take(itemsToTake).ToList(); // Взима първите P елемента
            myList4.RemoveRange(0, itemsToDelete);        // Премахва първите Q елемента, започвайки от индекс 0;


            if (myList4.Contains(numberToSearch)) // Проверява дали R го има в списъка
            {
                Console.WriteLine("YES!");
            }
            else
            {
                Console.WriteLine("NO!");
            }
            

            Console.WriteLine(String.Join(" ", myList4)); // Разпечатва какво е останало - НЕ СЕ ИЗИСКА ПО ЗАДАНИЕ


            // ПРОВЕРКА :
            // 12 412 123 21 654 34 65 3 23
            // 7 4 21                           РЕЗУЛТАТ : NO!


   */

            // ---------------------------------------------------------------------------------------------
            // ЗАДАЧА 5.**  Най-дълга нарастваще подредица (Longest Increasing Subsequence - LIS) ----------

            // ... to be continued ...



        }
    }
}
