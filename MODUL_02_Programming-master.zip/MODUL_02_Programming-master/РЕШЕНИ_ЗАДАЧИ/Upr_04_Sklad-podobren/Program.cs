﻿//// МОДУЛ_02; Папка 04; Файл 11 - Работа с масиви

using System;
using System.Linq;

namespace Upr_04_Sklad_podobren
{
    class Program
    {
        static void Main(string[] args)
        {

            // ВЪВЕЖДАНЕ НА МАСИВИТЕ С ПРОДУКТИ КОЛИЧЕСТВА И ЦЕНИ //////////////////////////////////////////////
            string[] Products = Console.ReadLine(). //Дефинираме масив за продукти и въвеждаместойностите от един ред
                           Split(" ").
                           //Select(int.Parse). // не е нужно "парсване", защото Console.ReadLine() подава стринг
                           ToArray();

            long[] Quantities = Console.ReadLine(). //Дефинираме масив за количества и въвеждаме стойностите от един ред
                           Split(" ").
                           Select(long.Parse).
                           ToArray();

            float[] Prices = Console.ReadLine(). //Дефинираме масив за цени и въвеждаме стойностите от един ред
                           Split(" ").
                           Select(float.Parse).
                           ToArray();


            // ДЕФИНИРАНЕ НА НУЖНИТЕ ПРОМЕНЛИВИ
            long available_quantity = 0; // Променлива, в която запазваме желаното количеството на търсения продукт

            long needed_quantity = 0;


            string product; // Променлива, в която запазваме желания продукт

            float sum = 0.00f;

            int index = -1; // Променлива, в която съхраняваме индекса на желания продукт
                            // Ако стойността му остане -1, значи не е намерен продукта


            // БЕЗКОНЕЧЕН ЦИКЪЛ ЗА ДИАЛОГ С ПОТРЕБИТЕЛЯ
            while (true)
            {

                string[] Order = Console.ReadLine(). //Дефинираме масив за поръчка - Продукт и Количество
                          Split(" ").
                          //Select(float.Parse).
                          ToArray();


                product = Order[0];// Четем продукт от първия елемент на масива Order
                
                if (product.Equals("done"))// Прекъсва програмата, ако е въведено done
                    break;


                needed_quantity = long.Parse(Order[1]);// Четем количеството от втория елемент на масива Order


                index = Array.IndexOf(Products, product); // Намира индекса на въведения продукт в масива 
                                                          // с продуктите


                // Проверяваме дали в масива с количествата има въведени количества за търсения продукт
                if (index > Quantities.Length-1 ) // ако в масива с количествата не се намира индекс за този продукт 
                {                               // т.е. масива с количествата е по-къс от масива с продуктите
                    available_quantity = 0;
                }

                else
                {
                    available_quantity = Quantities[index];// взимаме наличните количества

                }


                if (available_quantity == 0) // ако наличното количество е нула
                {
                    Console.WriteLine($"We do not have enough {Products[index]}");
                }
                else
                {
                    Quantities[index] = Quantities[index] - needed_quantity; // ако наличното количество е по-голямо 
                                                                             // от нула приспадаме от него желаното
                                                                             // кличество

                sum = (float)Math.Round(Prices[index] * needed_quantity, 2);
                Console.WriteLine($"{Products[index]} x {needed_quantity} costs {sum}");
                }


                



            }
        }
    }
}
