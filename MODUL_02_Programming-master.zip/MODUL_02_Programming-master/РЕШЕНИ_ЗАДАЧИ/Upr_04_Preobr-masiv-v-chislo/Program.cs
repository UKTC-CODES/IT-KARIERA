﻿using System;
using System.Linq;

namespace Upr_04_Preobr_masiv_v_chislo
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = Console.ReadLine(). //Дефинираме масив и въвеждаме стойности от един ред
                            Split(" ").
                            Select(int.Parse).
                            ToArray();

            int result = 0; // за съхраняване на крайния резултат



            while (numbers.Length>1) // докато масива numbers не остане само с 1 елемнт
            {

                int[] condnumbers = new int[numbers.Length - 1]; // нов масив с 1 елемент по-малък от маисва numbers,
                                                                 // защото след сумиране на 2 числа той ще намале с 1 елемент


                for (int i = 0; i < numbers.Length-1; i++)
                {
                    
                    //Console.WriteLine(i); временно за да следя преоразмеряването на масива
                    condnumbers[i] = numbers[i] + numbers[i + 1];// сумира 2 елемента от numbers и го записва в condnumbers

                }

                    numbers = condnumbers;  // приравнява numbers на condnumbers, защото е намален с 1 елемент след
                                            // сумирането на две числа, но трябва да продължи да сумира numbers
                    result = condnumbers[0];// записва резултата от окончателното сумиране в result, защото condnumbers е
                                            // "невидим" извън обхвата на while.
            }


            Console.WriteLine(result);

        }
    }
}
