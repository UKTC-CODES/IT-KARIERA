using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace SortSelection
{
    class Program
    {
        static void Main(string[] args)
        {
 
            Console.WriteLine("SELECTION SORT");
 
            int[] arr = new int[] { 25, 2, 44, -5, 117, 10, 0, 88, 49 , 44, 44};
 
            Console.WriteLine("Print BEFORE Sorting");
            Console.WriteLine(string.Join(" ", arr));
 
 
            for (int i = 0; i < arr.Length; i++)
            {
                int k = i;
                for (int j = i + 1; j < arr.Length; j++)
                {
                    if (arr[j] < arr[k])
                        k = j;
                }
                int swapVar = arr[i];
                arr[i] = arr[k];
                arr[k] = swapVar;
            }
 
            Console.WriteLine("Print AFTER Sorting");
            Console.WriteLine(string.Join(" ", arr));
        }
 
 
 
    }
}