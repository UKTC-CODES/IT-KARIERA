using System;
using System.Linq;
 
namespace Nai_chesto_ver._2
{
    class Program
    {
        static void Main(string[] args)
        {
 
            // Дефиниране на променливи
            int maxcount = 0; // кое число се среща най много
            int indexOf = 0; // на кое място в масива с броячите е
            int[] counters = new int[65536]; // броячи за брой срещания на всяко число
 
 
            // Въвеждане на стойностите от един ред и записване в масив наречен numbers
            int[] numbers = Console.ReadLine().
                                    Split(' ').
                                    Select(int.Parse).
                                    ToArray();
 
 
            // Преброяване на броя срещания на всяко число
            for (int i = 0; i < numbers.Length; i++)
            {
                int num = numbers[i];
 
                counters[num]++;
            }
 
           
 
            maxcount = counters.Max(); // взима брояча с най-голяма стойност
 
            for (int j = 0; j < 65536; j++)
            {
                if (counters[j] == maxcount)
                { indexOf = j; } // намира кое числото с най-много срещания
            }
 
            Console.WriteLine(indexOf);
        }
    }
}
