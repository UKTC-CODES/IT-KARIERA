using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace _3_Latin
{
    class Program
    {
        static void Main(string[] args)
        {
 
            Console.WriteLine("Input the number of letters : ");
            int length = int.Parse(Console.ReadLine());
 
 
            for (int i = 0; i < length; i++) // 1 FOR
            {
                char Letter01 = (char)('a' + i);
 
                for (int j = 0; j < length; j++)// 2 FOR
                {
                    char Letter02 = (char)('a' + j);
 
                    for (int k = 0; k < length; k++)// 3 FOR
                    {
                        char Letter03 = (char)('a' + k);
 
 
                        Console.WriteLine($"{Letter01}{Letter02}{Letter03}");
                    }
                }
            }
 
 
        }
    }
}
