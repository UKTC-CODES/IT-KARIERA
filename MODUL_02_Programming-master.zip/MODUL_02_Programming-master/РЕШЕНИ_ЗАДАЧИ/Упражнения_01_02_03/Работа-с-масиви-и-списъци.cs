using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
 
            /*
            int[] myMass = new int[10];
 
            for (int i = 0; i < myMass.Length; i++)
            {
                myMass[i] = i * 12;
            }
 
 
            for (int j = 0; j < myMass.Length; j++)
            {
                Console.WriteLine(myMass[j]);
            }
 
 
 
            string[] days = {   "Monday",
                                "Tuesday",
                                "Wednesday",
                                "Thursday",
                                "Friday",
                                "Saturday",
                                "Sunday" };
 
 
            int day = int.Parse(Console.ReadLine());
 
            if (day >= 1 && day <= 7)
                Console.WriteLine(days[day - 1]);
            else
                Console.WriteLine("Invalid day!");
 
 
            int[] myMass = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            for (int i = 0; i < myMass.Length; i++)
            {
                Console.WriteLine(myMass[i]);
            }
 
            // ГОТОВИ МЕТОДИ ЗА РАБОТА С МАСИВИ
 
 
            // Reverse ...................................................
                //int[] arr = new int[] { 2, 4, -5, 1, 10 };
                int[] arr = { 2, 4, -5, 1, 10 };
                Console.WriteLine(string.Join(" ", arr));
                Console.WriteLine();
 
            Array.Reverse(arr);
                Console.WriteLine(string.Join(" ", arr));
 
 
            // Sort .......................................................
           
                int[] arr1 = new int[] { 2, 4, -5, 1, 10 };
                Array.Sort(arr1);
                Console.WriteLine(string.Join(" ", arr1));
 
 
           
            // Clear .......................................................
            int pos = 3;
            int countOfZero = 2;
            int[] arr2 = new int[] { 2, 4, -5, 1, 10 };
            Array.Clear(arr2, pos, countOfZero);
            Console.WriteLine(string.Join("-", arr2));
 
            //
           
 
 
 
            int[] source = new int[] { 1, 2, 3 };
            int[] destination = new int[] { 7, 7, 7, 7, 7 };
 
            source.CopyTo(destination, 2);
            Console.WriteLine(string.Join(" ", destination));
 
 
 
            int[] source = new int[] { 2, 4, 6, 8, 10, 12, 14, 16 };
            int[] destination = new int[] { 1, 3, 5, 7, 9, 11, 13, 15, 17 };
            Array.Copy(source, 4, destination, 2, 3);
            Console.WriteLine(string.Join(" ", destination));
 
   
 
 
            var nums = new List<int> {
                                        10, 20, 30, 40, 50, 60};
            Console.WriteLine(
            String.Join(", ", nums));
 
 
            nums.RemoveAt(2);
            Console.WriteLine("RemoveAt 2 : "+
            String.Join(", ", nums));
 
            nums.Add(100);
            Console.WriteLine("Add(100) : "+
            String.Join(", ", nums));
 
            nums.Insert(2, -100);
            Console.WriteLine("Insert(2, -100) : "+
            String.Join(", ", nums));
 
 
            */
 
 
            string input = Console.ReadLine();// STRING FROM KEYBOARD [2 8 30 25 40 72 -2 44 56]
 
 
            //SPLIT input string () into part by space and place parts into List of strings
            List<string> items = input.Split(' ').ToList();
 
            foreach(string mystring in items)
                Console.WriteLine(mystring);
 
 
 
            List<int> nums = new List<int>();
 
            for (int i = 0; i < items.Count; i++)
 
                nums.Add(int.Parse(items[i]));
 
            nums.Add( int.Parse( input.Split( ' ' ).ToString() ) );
 
 
            foreach (int myint in nums)
                Console.WriteLine(myint);
 
        }
    }
}
