using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Lists
{
    class Program
    {
        static void Main(string[] args)
        {
 
            /*
            var names = new List<string>(); // създава списък от низове
 
            names.Add("Peter");
            names.Add("Maria");
            names.Add("George");
 
 
            for (int i = 0; i < names.Capacity ; i++)
            {
                Console.WriteLine(names);
            }
 
            //Console.WriteLine(String.Join(", ", names));
            // foreach (var name in names)
            //    Console.WriteLine(name);
 
 
            names.Remove("Maria");
 
 
            Console.WriteLine("After remove : ");
            Console.WriteLine(String.Join(", ", names));
 
         
 
            var nums = new List<int> {  70, 10, 20, 30, 40, 50, 60, 70, 80, 90,
                                        90, 80, 70, 60, 50, 40, 70, 30, 20, 10
                                     };
 
 
            Console.WriteLine("ORIGINAL : ");
            Console.WriteLine(String.Join(", ", nums));
 
 
            var capacity = nums.Capacity;
            Console.WriteLine("Capacity : " + capacity);
            var count = nums.Count;
            Console.WriteLine("Count : " + count);
 
 
 
            nums.Sort();
            Console.WriteLine("SORTED : ");
            Console.WriteLine(String.Join(", ", nums));
 
 
            nums.Reverse();
            Console.WriteLine("REVERSED : ");
            Console.WriteLine(String.Join(", ", nums));
 
            nums.RemoveAt(0);
            Console.WriteLine("RemoveAt 0 : ");
            Console.WriteLine(String.Join(", ", nums));
 
            nums.Insert(5, 77);
            Console.WriteLine("Insert 5, 77 : ");
            Console.WriteLine(String.Join(", ", nums));
 
 
 
            // while(nums.Contains(70))
            // {
            //     nums.Remove(70);
            // }
 
             
 
            Console.WriteLine("Input number of elements : ");
            int n = int.Parse(Console.ReadLine());
 
            List<int> list = new List<int>();
 
            for (int i = 0; i < n; i++)
            {
                list.Add(int.Parse(Console.ReadLine()));
            }
 
            Console.WriteLine(String.Join(", ", list));
 
 
 
            // /////////////////////////////////////////////////////////////////////
            // ВЪВЕЖДАНЕ НА СТОЙНОСТИ ОТ ЕДИН РЕД //////////////////////////////////
            // /////////////////////////////////////////////////////////////////////
 
            string values = Console.ReadLine(); // Дефинираме променлива values за вх стринг
 
            List<string> items = values.Split(' ').ToList(); // Разделяме values  по интервал
            string[] arrayItems = values.Split(' ').ToArray();
 
 
            Console.WriteLine("Print List of strings : ");
            Console.WriteLine(String.Join(", ", items));
 
            Console.WriteLine("Print Array of strings : ");
            Console.WriteLine(String.Join(", ", arrayItems));
 
 
 
            // Convert to LIST of Integers with FOR-Cycle //////////////////////////////////////
            List<int> nums = new List<int>();
 
            for (int i = 0; i < items.Count; i++)
            {
                nums.Add(int.Parse(items[i]));
            }
 
            Console.WriteLine("Print List of integers : ");
            Console.WriteLine(String.Join("; ", nums));
 
    */
 
 
            // ВСИЧКО ПО ГОРЕ НА ЕДИН РЕД //////////////////////////////////////
            List<int> nums2 = new List<int>();
            nums2 = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
 
            Console.WriteLine("Print List of integers : ");
            Console.WriteLine(String.Join("; ", nums2));
 
            // TO-DO - Remove negative elements
 
            Console.WriteLine("Print List of integers : ");
            Console.WriteLine(String.Join("; ", nums2));
 
 
 
        }
    }
}
