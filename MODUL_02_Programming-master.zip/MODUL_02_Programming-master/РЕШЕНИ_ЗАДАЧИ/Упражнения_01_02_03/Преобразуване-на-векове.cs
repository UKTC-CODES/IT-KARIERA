using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace MODUL_02
{
    class Program
    {
        static void Main(string[] args)
        {
            byte centuries = 0;    // Много малко число (до 255)
            ushort years = 0;    // Малко число (до 32767)
            uint days = 0;     // Голямо число (до 4.3 млрд.)
            ulong hours = 0; // Много голямо число (до 18.4*10^18)
            ulong minutes = 0;
 
            Console.WriteLine("Please input the number of centuries : ");
            centuries = byte.Parse(Console.ReadLine());
 
            years = (ushort)(centuries*100);
            days = (uint)(years * 365.2422);
            hours = days * 24;
            minutes = hours *60;
 
            Console.WriteLine("{0} centuries = {1} years = {2} days = {3} hours = {4} minutes.", centuries, years, days, hours, minutes);
 
            int Mariela = 0;
            Console.WriteLine($"Mariela : {Mariela}");
 
            Mariela = (int)1234l;
            Console.WriteLine($"Mariela : {Mariela}");
 
 
        }
    }
}