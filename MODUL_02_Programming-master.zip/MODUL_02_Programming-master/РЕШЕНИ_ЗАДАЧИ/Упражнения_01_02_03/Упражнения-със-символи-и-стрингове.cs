using System;
using System.Collections.Generic;
using System.Diagnostics; // STOPWACH
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace SymbolsStrings
{
    class Program
    {
        static void Main(string[] args)
        {
 
 
            /*
            string str;// = "Hello, C#";
            str = Console.ReadLine();
 
 
            char[] charArr = str.ToCharArray();
 
 
            //Console.WriteLine(String.Join(charArr));
 
            //foreach(char mychar in charArr)
            //   Console.Write(mychar);
 
            for (int i = 0; i < charArr.Length; i++)
            {
                Console.Write(charArr[i]);
            }
            */
 
 
            // bool eq = (str1 == str2);
            //Console.WriteLine(eq);
 
            // uses String.Equals(…)
 
            //if(str1 == "Hello 2")
            // { Console.WriteLine(str1); }
            // else
            //     Console.WriteLine("Not equal");
 
 
            //string str1 = "Hello 1";
            // string str2 = "hello 1";
 
            //bool eq1 = str1.Equals("Hello 1");
            // bool eq2 = str2.Equals("Hello 1");
            // Console.WriteLine(eq1);
            // Console.WriteLine(eq2);
 
 
 
            //int result = string.Compare(str1, str2, true);
            // int result = string.Compare(str1, str2, false);
 
            // result == 0 if str1 equals str2
            // result < 0 if str1 is before str2
            // result > 0 if str1 is after str2
 
 
 
            //string str1 = "Hello 1";
            // string str2 = "Hello 2";
 
 
            // string str = string.Concat(str1, " ", str2);
 
 
 
            // Console.WriteLine(str);
 
            // //////////////////////////////////////////////////////
            /*
            string email = "vasko@gmail.org";
 
            int Index1 = email.IndexOf("@"); // 5
            Console.WriteLine(Index1);
 
            int Index2 = email.IndexOf("a", 2); // 8
            Console.WriteLine(Index2);
 
            int Index3 = email.IndexOf(".", 2); // 11
            Console.WriteLine(Index3);
 
 
 
            int notFound = email.IndexOf("/"); // -1
            Console.WriteLine(notFound);
 
   
            //string verse = "To be or not to be… e me ve be";
            //int lastIndex = verse.LastIndexOf("be"); // 28
            //Console.WriteLine(lastIndex);
 
            //int ascii = 'T';
            // Console.WriteLine(ascii);
 
            // int lastIndex2 = verse.First(); //
            // Console.WriteLine(lastIndex2);
 
 
            string input = Console.ReadLine().ToLower();
            string pattern = Console.ReadLine().ToLower();
 
            int counter = 0;
            int index = input.IndexOf(pattern);
 
 
            while (index != -1)
            {
                counter++;
                index = input.IndexOf(pattern, index + 1);
            }
 
 
            Console.WriteLine(counter);
 
 
 
            string filename = @"C:\Pics\Rila2017.jpg";
            int index = filename.IndexOf("\\", 2);
 
            string name = filename.Substring(index+1);
 
            Console.WriteLine(name);
            // name == "Rila2017"
 
 
 
 
            string listOfBeers = "Amstel Zagorka, Tuborg, Becks.";
 
            string[] beers = listOfBeers.Split(' ', ',', '.');
 
            Console.WriteLine("Available beers are:");
 
            foreach (string beer in beers)
                Console.WriteLine(beer);
 
            */
 
            var timer = new Stopwatch();
            timer.Start();
 
            var result = new StringBuilder();
 
            for (int i = 0; i < 5000000; i++)
                result.Append(Convert.ToString(i, 2));
 
            Console.WriteLine(timer.Elapsed);
            Console.WriteLine(result.Length);
 
        }
    }
}