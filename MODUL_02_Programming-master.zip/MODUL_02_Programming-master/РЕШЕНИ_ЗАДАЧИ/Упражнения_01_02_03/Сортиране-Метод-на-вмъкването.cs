using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace SortInsertion
{
    class Program
    {
        static void Main(string[] args)
        {
 
            Console.WriteLine("INSERTION SORT");
 
            int[] arr = { 10, 4, 2, 1, -5 }; // REVERSED
            //int[] arr = { 2, 4, -5, 1, 10 }; // ORIGINAL
            //int[] arr = { -5, 1, 2, 4, 10 }; //SORTED
 
            Console.WriteLine("-----------------------");
            Console.WriteLine("Print BEFORE Sorting");
            Console.WriteLine(string.Join(", ", arr));
            Console.WriteLine("-----------------------");
 
 
            for (int i = 0; i < arr.Length; i++)
            {
                int swapVar = arr[i];
                int index = i;
 
                while (index > 0 && arr[index - 1] >= swapVar)
                {
                    arr[index] = arr[index - 1];
                    index--;
 
                    Console.WriteLine(string.Join(", ", arr));
                }
                arr[index] = swapVar;
 
               
            }
            Console.WriteLine("-----------------------");
            Console.WriteLine("Print AFTER Sorting");
            Console.WriteLine(string.Join(", ", arr));
            Console.WriteLine("-----------------------");
        }
 
 
 
    }
}