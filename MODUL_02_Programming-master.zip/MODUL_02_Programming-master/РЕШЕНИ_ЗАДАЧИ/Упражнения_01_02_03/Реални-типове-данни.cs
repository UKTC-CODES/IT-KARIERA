using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace REALDataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
 
            /*
 
            // Defferent precision //////////////////////////////////////////
 
            float floatPI =     3.141592653589793238f;
            double doublePI =   3.141592653589793238;
            Console.WriteLine("Float PI is: {0}", floatPI);
            Console.WriteLine("Double PI is: {0}", doublePI);
 
 
            // Round //////////////////////////////////////////////////////
 
            double a = 2.3455;
            Console.WriteLine(a);
            Console.WriteLine();
 
            Console.WriteLine(Math.Round    (a));    // result: 2
            Console.WriteLine(Math.Round    (a, 3)); // result: 2.346
            Console.WriteLine(Math.Ceiling  (a));  // result: 3
            Console.WriteLine(Math.Floor    (a));    // result: 2
 
 
 
            // Circle area /////////////////////////////////////////////////
 
            double r = double.Parse(Console.ReadLine());
            Console.WriteLine("{0:f12}", Math.PI * r * r);
 
 
 
            // Exponential ////////////////////////////////////////////////
 
            double d = 10000000000000000000000000000000000.0;
            Console.WriteLine(d); // 1E+34
            double d2 = 20e-3;
            Console.WriteLine(d2); // 0.02
 
            double d3 = double.MaxValue;
            Console.WriteLine(d3); // 1.79769313486232E+308
 
            double d4 = double.MinValue;
            Console.WriteLine(d4); // 1.79769313486232E+308
           
 
           
            // Division with float point ////////////////////////////////////
 
            Console.WriteLine(10 / 4);      // 2 (целочислено)
            Console.WriteLine(10 / 4.0);    // 2.5 (реално)
            Console.WriteLine(10 / 0.0);    // Infinity
            Console.WriteLine(-10 / 0.0);   // -Infinity
            Console.WriteLine(0 / 0.0);     // NaN (не е число)
            Console.WriteLine(8 % 2.5);     // 0.5 (3 * 2.5 + 0.5 = 8)
            int d = 0;                      // Целочисленото деление работи по друг начин!
            Console.WriteLine(10 / d);      // DivideByZeroException
 
 
 
            // ANOMALII ////////////////////////////////////////////////////
 
            Console.WriteLine(100000000000000.0 + 0.3);
            // Result: 100000000000000 (загуба на точност)
            double a = 1.0f, b = 0.33f, sum = 1.33;
            Console.WriteLine("a+b={0} sum={1} equal={2}",
              a + b, sum, (a + b == sum));
            // a+b=1.33000001311302 sum=1.33 equal=False
            double one = 0;
            for (int i = 0; i < 10000; i++) one += 0.0001;
            Console.WriteLine(one); // 0.999999999999906
 
            */
 
 
 
            // INTEGER and REAL - EXPERIMENTS ////////////////////////////////
 
            int n = int.Parse(Console.ReadLine());
            decimal sum = 0;
 
            for (int i = 0; i < n; i++)
                sum += decimal.Parse(Console.ReadLine());
 
            Console.WriteLine(sum);
            Console.WriteLine("{0:f20}",sum);
 
 
 
        }
    }
}