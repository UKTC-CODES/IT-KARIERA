using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace SortBubble
{
    class Program
    {
        static void Main(string[] args)
        {
 
            Console.WriteLine("BUBBLE SORT");
 
            int[] arr = new int[] { 2, 4, -5, 1, 10 };
 
            Console.WriteLine("Print BEFORE Sorting");
            Console.WriteLine(string.Join(", ", arr));
 
 
            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int j = 0; j < arr.Length - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int swapVar = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = swapVar;
                    }
                    //Console.WriteLine("     Inner : ");
                    //Console.WriteLine(string.Join(", ", arr));
                }
                //Console.WriteLine("Outer : ");
                //Console.WriteLine(string.Join(", ", arr));
            }
 
 
            Console.WriteLine("Print AFTER Sorting");
            Console.WriteLine(string.Join(", ",arr));
 
        }
    }
}