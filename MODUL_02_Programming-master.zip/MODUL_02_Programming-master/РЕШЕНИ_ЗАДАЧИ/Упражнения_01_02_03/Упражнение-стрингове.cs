using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace TextTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            string file1 = "C:\\Windows\\win.ini";
            //string file2 = "C:\Windows\win.ini";
            string file3 = @"C:\Windows\win.ini";
 
            string firstName = "Krasimir";
            string lastName = "Nakov";
            string fullName = $"{firstName} {lastName}";
            string fullName2 = firstName + " " + lastName;
 
            Console.WriteLine(fullName);
            Console.WriteLine(fullName2);
 
         
 
            string firstName = "Ivan";
            string lastName = "Ivanov";
            Console.WriteLine(@" Hello, {0}! ", firstName);
            Console.WriteLine(@" Hello, ""{0}""! ", firstName);
 
 
            string fullName = $"{firstName} {lastName}";
 
            Console.WriteLine("Your full name is {0}.", fullName);
            Console.WriteLine($"Your full name is {fullName}.");
 
       
 
 
            string firstName = Console.ReadLine();
            string lastName = Console.ReadLine();
            string ageStr = Console.ReadLine();
            int age = int.Parse(ageStr); //Преобразуване string  int
            Console.WriteLine($"Hello, {firstName} {lastName}.\r You are {age} years old.");
            Console.WriteLine($"Hello, {firstName} {lastName}.\n You are {age} years old.");
            Console.WriteLine($"Hello, {firstName} {lastName}.\r\n You are {age} years old.");
            Console.WriteLine($"Hello, {firstName} {lastName}.\n\r You are {age} years old.");
 
            string a = "Hello";
            string b = "World";
            object c = a + " " + b;
            string d = (string)c;
            Console.WriteLine(c);
 
       
            double length;
            Console.Write("Length: ");
            length = double.Parse(Console.ReadLine());
 
            double width;
            Console.Write("Width: ");
            width = double.Parse(Console.ReadLine());
 
            double height;
            Console.Write("Height: ");
            height = double.Parse(Console.ReadLine());
 
 
            double volume = 0;
            volume = (length * width * height) / 3;
            Console.WriteLine("Pyramid Volume: {0:F2}", volume);
       
 
            int number = int.Parse(Console.ReadLine());
            int sum = 0;
            int that = 0;
            bool itIs = false;
 
            for (int i = 1; i <= number; i++)
            {
                that = i;
                while (i > 0)
                {
                    sum += i % 10;
                    i = i / 10;
                }
 
                itIs = (sum == 5) || (sum == 7) || (sum == 11);
 
                Console.WriteLine($"{that} -> {itIs}");
                sum = 0; i = that;
               
            */
 
        }
    }
    }