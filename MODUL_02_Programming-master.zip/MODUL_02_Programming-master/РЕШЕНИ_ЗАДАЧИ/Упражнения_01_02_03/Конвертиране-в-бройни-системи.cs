using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Convert_Example
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Input DECIMAL value :");
            //int numsdecimal = Convert.ToInt32(Console.ReadLine(), 10);
 
            Console.WriteLine("Input HEXA-DECIMAL value :");
            int numshexa = Convert.ToInt32(Console.ReadLine(), 16);
            Console.WriteLine(numshexa);
            string output_1 = "Hexa to Binary Value: " + Convert.ToString(numshexa, 2);
            string output_2 = "Hexa to Octa Value: " + Convert.ToString(numshexa, 8);
            Console.WriteLine(output_1);
            Console.WriteLine(output_2);
            Console.WriteLine();
 
 
            Console.WriteLine("Input OCTA value :");
            int numsocta = Convert.ToInt32(Console.ReadLine(), 8);
            Console.WriteLine(numsocta);
            string output_3 = "Octa to Binary Value: " + Convert.ToString(numsocta, 2);
            string output_4 = "Octa to Hexa Value: " + Convert.ToString(numsocta, 16);
            Console.WriteLine(output_3);
            Console.WriteLine(output_4);
            Console.WriteLine();
 
 
            Console.WriteLine("Input BINARY value :");
            int numsbin = Convert.ToInt32(Console.ReadLine(), 2);
            Console.WriteLine(numsbin);
            string output_5 = "Bin to Octa Value: " + Convert.ToString(numsbin, 8);
            string output_6 = "Bin to Hexa Value: " + Convert.ToString(numsbin, 16);
            Console.WriteLine(output_5);
            Console.WriteLine(output_6);
            Console.WriteLine();
        }
    }
}
