﻿//  ВИДИН - МОДУЛ_02; Упражнение 04 ; DOC-ФАЙЛ 18 - НАЙ-ДЪЛГАТА НАРАСТВАЩА РЕДИЦА;
//                                                  LIS - Longest Increasing Subsequence

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Upr_04_DOC_18_L_I_S
{
    class Program
    {
        static int seqMaxIDX = 0;


        static void Main(string[] args)
        {
            // Входен списък
            List<int> Input = Console.ReadLine().
                                Split(" ").
                                Select(int.Parse).
                                ToList();

            int lastIDX = Input.Count - 1; //Последния индекс на входния списък (т.е. подаваме целия списък)


            // СКАНИРАНЕ ЗА ТЪРСЕНЕ НА НАРАСТВАЩИ ПОРЕДИЦИ -------------------------------------------------------------

            ListScann(lastIDX, Input, false); // дължина на входния списък, входен списък, false - без печат


            // РАЗПЕЧАТВАНЕ НА НАЙ-ДЪЛГАТА ПОРЕДИЦA -----------------------------------------------------------

            ListScann(seqMaxIDX, Input, true); // дължина на слисъка до Н Н П, входен списък, true - с печат

        } // main




        // ListScann - МЕТОД ЗА СКАНИРАНЕ НА МАСИВА ///////////////////////////////////////////////////////

        static void ListScann(int lastIDX, List<int> Input, bool print)
        {

            // Списък с най-дълга нарастваща поредица (ННП)
            List<int> LIS = new List<int>();

            // Масив със намерени последователности - от него ще търся най дългата нарастваща поредица (ННП)
            int[] sequences = new int[Input.Count];

            LIS.Add(Input[0]);



            for (int i = 0; i <= lastIDX; i++)
            {

                // Console.WriteLine("Input : " + Input[i]); // ВРЕМЕННО за контрол

                // 1. Когато последния елемент от списъка с ННП e по-голям или равен на
                // поредния елемент от входния списък - ЗАМЕНЯМЕ
                if (LIS.Last() >= Input[i])
                {
                    LIS[LIS.Count - 1] = Input[i];


                    if (LIS.Count > 1)
                    {
                        // Последователно придвижваме малкия елемент напред докато среща по-голям
                        // от себе си и изтриваме всичко след него
                        while (LIS[LIS.Count - 2] >= LIS[LIS.Count - 1] && LIS.Count >= 1)
                        {
                            LIS[LIS.Count - 2] = LIS[LIS.Count - 1]; // предходния става равен на последния

                            LIS.RemoveAt(LIS.Count - 1); // Изтриваме последния

                            // Console.WriteLine(String.Join(", ", LIS)); // ВРЕМЕННО за контрол
                            if (LIS.Count == 1) { break; } // Ако списъка с ННП е останал само с 1 елемент
                        }
                    }
                }


                // 2. Когато последния елемент от списъка с ННП e по-малък от
                // поредния елемент от входния списък - ДОБАВЯМЕ
                if (LIS.Last() < Input[i])
                {
                    LIS.Add(Input[i]);
                }
                sequences[i] = LIS.Count();// Съхранява дължините на всички намерени последователности
            }

            seqMaxIDX = Array.IndexOf(sequences, sequences.Max()); // Индекса на последниия елемент в най-дългата поредица


            // Console.WriteLine("Max Seq Index : " + seqMaxIDX); // ВРЕМЕННО за контрол
            // Console.WriteLine("sequences : " + String.Join(" ", sequences)); // ВРЕМЕННО за контрол

            if (print) { Console.WriteLine(String.Join(" ", LIS)); }
        }

    } // class
} // namespace



// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ЗА ПРОБА : 11 12 13 3 14 4 15 5 6 7 8 7 16 9 17 10 19
// РЕЗУЛТАТ 1 : 11 12 13 14 15 16 17 19
// РЕЗУЛТАТ 2 : 3 4 5 6 7 8 9 10

// TRY IT : 5 5 1 6 30 7 2 35 3 4 5 40 6 8 45 9 10 12 15 20 25 50 55 60 65 70 75 80 85 90 0 95 10 17
// ANSWER : 1 2 3 4 5 6 8 9 10 12 15 20 25 50 55 60 65 70 75 80 85 90 95