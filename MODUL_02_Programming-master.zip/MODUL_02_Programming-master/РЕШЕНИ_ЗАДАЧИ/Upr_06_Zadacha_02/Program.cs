﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// ПРЕОБРАЗУВАНЕ N-ИЧНА В 10-ИЧНА :




namespace Upr_06_Zadacha_02
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int N, D;               // N- основа на бройната система; D-число в N-ична за преобразуване
                                    // var remain = new List<int>(); // Създава списък за остатъците

            string ChisloToString;  // Променлива за преобразуване на число в стринг
            int i;                  // брояч за цикъл
            int result = 0;         // За крайния резултат
            int power;              // Степени на основата
            int ResultConv;         // За конвертиране на символ в цифра
           

            // Четене от един ред -----------------------------------------------------
            int[] read = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();

            N = read[0];
            D = read[1];

            //-------------------------------------------------------------------------


            ChisloToString = D.ToString(); // Преобразува числото в стринг
          

            char[] ChToStrChar = ChisloToString.ToCharArray(); //Преобразува стринга в char-масив

            int count = ChToStrChar.Length; // Брояч от колко цифри е числото
          


            if (N >= 2 && N <= 10)

            {
                // Изчисляване в десетична бройна система

                for (i=0; i<count; i++)
                {

                    power = (int)Math.Pow(N, i); // Изчислява степента на основата (N  на степен i)




                    // [count-1-i], защото индексите са в обратна посока на нарастване на степента; -'0', за да получа цифра от ASCII;
                    ResultConv = Convert.ToInt32(ChToStrChar[count-1-i]-'0');
                    

                   
                    result = result + (ResultConv*power);
                    

                }

                Console.WriteLine();
                Console.WriteLine(result);

                

            }
            else
                Console.WriteLine(0);
                       

        }
    }
}
