﻿using System;
using System.Linq;

namespace Upr_04_Bezopasna_obrabotka_na_masiv
{
    class Program
    {

        /*
         
        Вие ще получите масив от низове и трябва да изпълните командите под тях.Вие можете да получите три команди:

    •	Reverse – обръща реда в масива
    •	Distinct – изтрива всички неуникални(повтарящи се) елементи на масива
    •	Replace {index} {string} – замества елемента на дадената позиция index  с низ string, който ви е даден

        */


        static void Main(string[] args)
        {

            string[] Input = Console.ReadLine(). //Дефинираме масив и въвеждаме стойностите от един ред
                            Split(" ").
                            //Select(int.Parse).
                            ToArray();



            while(true)// безкраен цикъл за команди
            {

                // Чете командата от клавиатурата и слага всяка част в отделен стринг
                string[] command = Console.ReadLine(). // дефинира масив за въвеждане на команда
                                   Split(" ").         // командата е като масив от стрингове разделени с интервал
                                   ToArray();          // елемент[0] е командата
                                                       // другите [1][2]...[n], ако има са параметри



                // Анализ на командата и изпълнението ///////////////////////////////////////////////

                // команда Reverse - обръща масива в обратен ред
                if (command[0].Equals("Reverse"))
                {
                    Array.Reverse(Input);
                    continue;
                }

                // команда Distinct - премахва дублиращи се елемнти
                if (command[0].Equals("Distinct"))
                {
                        Input = Input.Distinct().ToArray();
                        continue;
                }

                // команда Replace - заменя елемента от даден индекс с друг елемент    
                if (command[0].Equals("Replace")) // елемент[0] - команда
                {
                    int index = int.Parse(command[1]);  // елемент[1] - параметър 1 (индекса)
                    string replace = command[2];        // елемент[2] - параметър 2 (думата с която да заменим)

                        if (index < 0 || index > Input.Length - 1) // Ако не съществува такъв индекс
                            Console.WriteLine("Invalid index !");
                        else
                            Input[index] = replace;

                        continue;
                }
                

                if (command[0].Equals("END"))
                {
                        break;
                }
                
                else
                {
                    Console.WriteLine("Invalid command !"); // Ако не съществува такава команда
                    continue;
                }

            }

            Console.WriteLine(String.Join(", ", Input));// Това е крайния резултат

        }
    }
}
