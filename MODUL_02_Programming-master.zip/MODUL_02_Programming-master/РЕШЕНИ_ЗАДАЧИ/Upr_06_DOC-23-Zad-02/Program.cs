﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 23 - Задача 1, 2, 3, 4
// ВИДИН_Модул-02_Упр-06_DOC-file-23_Зад-2

using System;
using System.Collections.Generic;


namespace Upr_06_DOC_23_Zad_02
{
    internal static class Program
    {
        private static void Main(string[] args)
        {

            string inputStr = Console.ReadLine();        // Входен стринг
            List<int> occureIndex = new List<int>();     // Списък с индексите на които има срещания на цифра
            char[] inputToChar = inputStr.ToCharArray(); // Входни стринг конвертиран към масив от символи
            char letter;                                 // Буквата с която да заменим цифрите


            // Цикъл за обхождане на входния стринг
            for (int i = 0; i < inputToChar.Length; i++)
            {

                // Проверка за срещане на цифра
                while ( inputToChar[i] >= 48 && inputToChar[i] <= 57 ) // 48 е ASCII-кода на '0'; 57 ASCII на '9'
                {
                    occureIndex.Add(i); // Ако се срещне цифра се записва нейния индекс
                    i++;

                    if (i == inputToChar.Length)
                    { break; }

                }

                if (i < inputToChar.Length)
                {
                    letter = inputToChar[i];

                    // заменя цифрите с буквата след тях

                    for (int j = 0; j < occureIndex.Count; j++)
                    {
                        inputToChar[occureIndex[j]] = letter;
                    }

                    occureIndex.Clear(); // Нулира списъка със срещанията

                }

            }

            Console.WriteLine(String.Join("", inputToChar));
        }
    }
}



// ПРОВЕРКА : aa123Bccc986Dffff4645684Rsss
// РЕЗУЛТАТ : aaBBBBcccDDDDffffRRRRRRRRsss
