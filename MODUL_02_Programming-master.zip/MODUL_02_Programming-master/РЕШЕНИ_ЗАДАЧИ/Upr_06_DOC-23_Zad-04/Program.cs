﻿// ВИДИН - МОДУЛ_02 - Упражнение_06 - DOC-файл 23 - Задача 1, 2, 3, 4
// ВИДИН_Модул-02_Упр-06_DOC-file-23_Зад-4


using System;

namespace Upr_06_DOC_23_Zad_04
{
    internal static class Program
    {
        private static void Main(string[] args)
        {
            string bannedWord = Console.ReadLine();
            string sentence = Console.ReadLine();

           
                if (sentence.Contains(bannedWord))
                {
                    sentence = sentence.Replace(bannedWord, new string('*', bannedWord.Length));
                }

            Console.WriteLine(sentence);

        }
    }
}


// ПРОВЕРКА : Java
// ПРОВЕКА  : I love C# and JavaScript, but I hate RxJava
// ОТГОВОР :  I love C# and ****Script, but I hate Rx****
